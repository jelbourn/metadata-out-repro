export const VERSION = 1;
