export class Test2 {
  public test = 456;
}
