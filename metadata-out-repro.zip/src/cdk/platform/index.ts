import {Test2} from '@angular/cdk/other';

export class Test {
  public test = 123;
}
