import {Test} from './index';

console.log(new Test());
