declare const something: any;
